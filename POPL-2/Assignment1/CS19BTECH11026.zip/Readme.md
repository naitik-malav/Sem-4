# Assignment-1

Name: Naitik Malav
Roll No: CS19BTECH11026

## Navigation-Commands, Compilation and running steps

1. First of all navigate to the folder where you have saved/downloaded my source codes.
2. Now type make command. It will open Makefile and compiles main.cpp and stack0.cpp together and it will save  generated binary final namely - stack0 into bin folder.
3. Now navigate to the bin folder using cd bin/ command.
4. Execute generated binary files. For eg enter ./stack0 to execute stack0
5. After that user is prompted to input according to the question and output will be displayed.
6. To execute other binary files do the same thing. Just enter ./stack1 ... 

## stack.h
Here I have defined class namely Stack, with public parameters like long long int data and next pointer inside it. By defining here it can be accessed by all the cpp files which are including stack.h header file. Also I have added all needed functions prototypes here.

## stack0.cpp
1. Contains all the needed functions like-
```bash
push_stack
pop_stack
create_stack
``` 

## main.cpp
It prompts user for operations, etc. Here I have called create_stack, push_stack and pop_stack which I have defined in stack0.cpp. 

## Examples and few Screenshots
Here's the drive [link](https://drive.google.com/drive/folders/1e5kj4MbLRyUzz1imCyf5IHGhrmV8GaA2?usp=sharing) for screenshot. You can follow this link if you find any difficulty in above steps. Also it'll easily explain you all the steps. I have tested few inputs and program runs successfully.