first of all open terminal and change directory to where you have downloaded my files.
then run below commands for compilation and execution

For RMS:
    For compilation:
        g++ Assgn2-RMScs19btech11026.cpp -o ./edf
    To run:
        ./rms

For EDF:
    For compilation:
        g++ Assgn2-EDFcs19btech11026.cpp -o ./edf
    To run:
        ./rms