Open terminal: and move to the directory wherever you have download/saved my source code.

A). For Asgn1_CS19BTECH11026_mth1.c :

        1. Compile using: 
            gcc Asgn1_CS19BTECH11026_mth1.c -pthread -lm -o ./heli1
        
            To run:  ./heli1

        2. Output will be saved in the file named "output.txt"


B). For Asgn1_CS19BTECH11026_mth2.c :

        1. Compile using:
            gcc Asgn1_CS19BTECH11026_mth2.c -pthread -lm -o ./heli2
        
            To run:  ./heli2

        2. Output will be saved in the file named "output.txt"

NOTE: -pthread is used to invoke thread library, and -lm is for math.h library because I have used pow function
So beware to add -lm and -pthread at last(while compiling) for proper functioning of code.