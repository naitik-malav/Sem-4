/* Asgn1_sol2_CS19BTECH11026
    Name: Naitik Malav
    Roll No.: CS19BTECH11026
*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h> 
#include<math.h>
#include<limits.h>
#include<sys/time.h>
#include<pthread.h> 

int part=0;
int n, p, ArraySize, TotalThreads; //ArraySize=2^n, TotalThreads=2^p 

struct info {
    long int *ptr;   //ptr to array
    int low;    //indexes
    int high;   //indexes
};

// merge function for merging two parts 
void merge(long int Array[], int low, int pivot, int high) 
{ 
    int n1=pivot-low+1, n2=high-pivot;      // n1 is size of left part and n2 is size of right part 
    long int left[n1], right[n2];
    
    for(int t=0; t<n1; t++)     // storing values in left part
        left[t] = Array[t+low];
  
    for(int t=0; t<n2; t++)     // storing values in right part 
        right[t] = Array[t+pivot+1]; 
  
    int i=0, j=0, k=low;  
    while(i<n1 && j<n2) {       // merging left and right in ascending order 
        if(left[i] <= right[j]) 
            Array[k++] = left[i++]; 
        else
            Array[k++] = right[j++]; 
    } 

    while(i < n1)       // inserting remaining values from left
        Array[k++] = left[i++]; 

    while(j < n2)       // inserting remaining values from right
        Array[k++] = right[j++]; 
} 

//used to set ptr of struct info*temp back to 0th index of Array
void setArrayPointer(struct info *temp, int ctr) {
    for(int i=0; i<ctr; i++)
        temp->ptr--;
}

void insertionSort(long int arr[], int size) {
    long int key;
    int j; 
    for (int i=1; i<size; i++) { 
        key = arr[i]; 
        j = i-1; 
        /* Move elements of arr[0..i-1], that are greater than key, 
        to one position ahead of their current position */
        while (j>=0 && arr[j]>key) { 
            arr[j+1] = arr[j]; 
            j = j-1; 
        } 
        arr[j+1] = key; 
    } 
}

/* Thread function, Read below comments for step-by-step explanation */
void* threadFunc(void *arg) 
{
    struct info *temp = (struct info*)arg;
    int thread_part = part++; 
  
    /*1. calculating low and high; the part of array lies between 'low'th to 'high'th index
    is that, for which we have alloted a particular thread. 
    2. Also we are going to use insertion sort to sort the part of array lies between low and high index */
    int low = thread_part*(ArraySize/TotalThreads); 
    int high = (thread_part+1)*(ArraySize/TotalThreads)-1; 
  
    /* moving ptr to 'low'th position bor you can say to that particular part of array which we are gonna
    sort using insertion sort. */
    for(int i=0; i<low; i++)
        temp->ptr++;

    if(low < high)
        insertionSort(temp->ptr, high-low+1);   //high-low+1 is basically size of the part to which one thread is assigned
    
    setArrayPointer(temp, low);     //moving pointer back to 0th index of Array
    return 0;
}

void *slaveThreadFunc(void *arg) {
    struct info *temp = (struct info*)arg;
    int mid = temp->low + (temp->high-temp->low-1)/2;
    merge(temp->ptr, temp->low, mid, temp->high);
    return 0;
}

int main(void)
{   
    FILE *fptr;     //ptr to the file
    fptr = fopen("inp.txt", "r"); 
    fscanf(fptr, "%d %d", &n, &p);      //scanning values of n and p
    fclose(fptr);

    ArraySize = pow(2, n);      //ArraySize = 2^n
    TotalThreads = pow(2, p);       //TotalThreads = 2^p
    
    FILE *fout;
    fout = fopen("output.txt", "w");

    long int Array[ArraySize];
    fprintf(fout, "Value of n=%d, p=%d\n", n, p);
    fprintf(fout, "Initial Array: ");        //printing initial unsorted array
    for(int i=0; i<ArraySize; i++) {
        Array[i] = rand()%1000;      //random values between 0 to 1000 
        fprintf(fout, "%ld ", Array[i]);
    }

    struct info *temp = (struct info*)malloc(sizeof(struct info));
    temp->ptr = &Array[0];

    /* variables used to calculate the time of sorting, 
    initialTime and finalTime stores value of clock at the start and end respectively */   
    struct timeval initialTime, finalTime;
    gettimeofday(&initialTime, NULL);

    /* creating and joining all 2^p threads */
    pthread_t Threads[TotalThreads];
    for (int i = 0; i<TotalThreads; i++) 
        pthread_create(&Threads[i], NULL, threadFunc, temp);    //passing temp as arg into threadFunc
  
    for (int i=0; i<TotalThreads; i++) 
        pthread_join(Threads[i], NULL); 
    
    /* method-2 of question */
    int i=1;
    while(p-i >= 0) {   //means if segments are greater than equal to 1 
        int k = pow(2, p-i);    //k=2^(p-1)
        struct info *slaveTemp[k];      //every selement to array stores diff value of low, high
        for(int t=0; t<k; t++)
            slaveTemp[t] = (struct info*)malloc(k*sizeof(struct info));     //allocating memory
        
        pthread_t slaveThreads[k];      //declaring k threads which are exactly half the number of segements
        
        /* with the help of below procedure i am passing the value of low and high to slaveThreadFunc 
            1.suppose n=4, p=3
                then in this case values of low, high are: (0, 3), (4, 7), (8, 11), (12, 15)
            2. After first loop, total segments gets halved so low and high are:
                (0, 7), (8, 15)
            3. and at last, low and high: (0, 15)  */
        for(int t=0; t<k; t++) {
            if(t==0) {
                slaveTemp[0]->low = 0;
                slaveTemp[0]->high = 0 + pow(2, (n-p+i)) - 1;
            }

            slaveTemp[t]->ptr = temp->ptr;      //pointing it to Array
            pthread_create(&slaveThreads[t], NULL, slaveThreadFunc, slaveTemp[t]);  //creating threads

            if(t+1<k) {
                slaveTemp[t+1]->low = slaveTemp[t]->low + pow(2, (n-p+i));     //adjusting indexes value, ie. low 
                slaveTemp[t+1]->high = slaveTemp[t+1]->low + pow(2, (n-p+i)) - 1;     //adjusting indexes value i.e. high
            }
        }

        for(int t=0; t<k; t++)
            pthread_join(slaveThreads[t], NULL);    //joining all threads
        
        i++;
    } 
    gettimeofday(&finalTime, NULL); 
    long int time1=(initialTime.tv_sec*1000000+initialTime.tv_usec);      //time1 is initialTime in microseconds 
    long int time2=(finalTime.tv_sec*1000000+finalTime.tv_usec);      //time2 is finalTime in microseconds  

    fprintf(fout, "\n\nSorted array: ");     //displaying sorted array
    for (int i = 0; i<ArraySize; i++) 
        fprintf(fout, "%ld ", *temp->ptr++);
    fprintf(fout, "\n\nTime Taken: %ldus", time2-time1);
    fprintf(fout, "\n\n");
}